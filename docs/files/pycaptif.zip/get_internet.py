#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
Script used to deconnect the machine from the internet with catpive portal

Needed on the machine : python3-selenium python3-pyvirtualdisplay :
pip3 install pyvirtualdisplay selenium
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By

import getpass
from pyvirtualdisplay import Display

new_driver_path = '/usr/bin/geckodriver'
new_binary_path = '/usr/bin/firefox'

user = input('Nom utilisateur: ')
pwd = getpass.getpass()

# Define the option to use headless mode. Headless mode allow to use firefox
# without any graphical windows involved. Useful in non graphical ssh
ops = Options()
ops.add_argument('--headless')
ops.binary_location = new_binary_path

display = Display(visible=0, size=(800, 600))
display.start()

serv = Service(new_driver_path)
driver = webdriver.Firefox(service=serv, options=ops)

driver.get("https://webauth.telecom-bretagne.eu/login.html")
assert "Web Authentication" in driver.title
elem = driver.find_element(By.NAME, "username")
elem.send_keys(user)
elem = driver.find_element(By.NAME, "password")
elem.send_keys(pwd)
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()
display.stop()
