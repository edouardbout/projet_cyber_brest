#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
Script used to deconnect the machine from the internet with catpive portal

Needed on the machine : python3-selenium python3-pyvirtualdisplay :
pip3 install pyvirtualdisplay selenium
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By

from pyvirtualdisplay import Display

new_driver_path = '/usr/bin/geckodriver'
new_binary_path = '/usr/bin/firefox'

# Define the option to use headless mode. Headless mode allow to use firefox
# without any graphical windows involved. Useful in non graphical ssh
ops = Options()
ops.add_argument('--headless')
ops.binary_location = new_binary_path

display = Display(visible=0, size=(800, 600))
display.start()

serv = Service(new_driver_path)
driver = webdriver.Firefox(service=serv, options=ops)

driver.get("http://1.1.1.1/logout.html")
elem = driver.find_element(By.NAME, "Logout")
elem.submit()
driver.close()
display.stop()
